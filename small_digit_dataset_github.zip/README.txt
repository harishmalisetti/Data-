Small synthetic digit image dataset for GitHub demos.
Image size: 28x28 grayscale PNG. Labels are folder names 0-9.
Train: 8 images per digit (80 total). Test: 2 images per digit (20 total).
IMPORTANT: These are synthetic sample images, NOT the official MNIST dataset.
For real MNIST, your notebook already loads it with keras.datasets.mnist.load_data().
